# `@basketball-os/public-contracts`

Browser-safe public data boundary shared by Basketball OS producers, team
dashboards, and future native clients. The package contains no React, provider
adapter, credential, private-evidence, or Node crypto dependency.

## Public contract

`TeamSnapshotV3` contains the complete current public team surface:

- tenant, league, season, team, provider, timezone, and canonical video-channel
  identity;
- source capabilities and audit references;
- team summary, roster, schedule/results, standings, leaders, derived team
  statistics, and published box scores;
- one explicit `GameVideoAvailability` per game:
  - `verified_exact` with its direct video, title, channel, and match provenance;
  - `channel_only` with `not_found`, `ambiguous`, or `source_unavailable`;
  - `not_expected` for a `bye` or `canceled` game.

`not_checked` is an internal collection state. It is deliberately absent from
the public union and fails parsing. Every Zod object is strict, so unknown data
cannot silently cross the boundary.

```ts
import {
  parseTeamSnapshotV3,
  type TeamSnapshotV3,
} from "@basketball-os/public-contracts"

const snapshot: TeamSnapshotV3 = parseTeamSnapshotV3(untrustedJson)
```

Consumer UI code that needs no runtime validator can use type-only imports:

```ts
import type {
  GameVideoAvailability,
  TeamSnapshotV3,
} from "@basketball-os/public-contracts/types"
```

## V2 migration and semantic hashes

V2 flattened video fields require a new V3 semantic hash. The migration API
never presents the old V2 hash as a valid V3 hash:

```ts
const candidate = prepareTeamSnapshotV2Migration(v2Input)
const canonical = canonicalSnapshotContentV1(candidate)
const contentHash = sha256Utf8InTheTrustedRuntime(canonical)
const snapshot = finalizeTeamSnapshotV3Migration(candidate, contentHash)
```

`migrateTeamSnapshotV2ToV3(v2Input, contentHash)` is the corresponding
convenience function when the caller has already computed the V3 hash.
`parseTeamSnapshot(v2Input)` fails closed with a rehash-required
`SnapshotValidationError`.

Content-hash version 1 covers every rendered public semantic field. It excludes
`generatedAt`, `contentHash`, and the volatile `checkedAt`/raw `hash` fields of
source references; source labels and URLs remain covered. This keeps unchanged
validated syncs stable. Cryptographic SHA-256 stays in the trusted signing
runtime so this package remains portable to browsers.

`canonicalJsonV1` (also exported as `canonicalJson`) uses deterministic Unicode
code-point key ordering, preserves array order, and uses JavaScript JSON
number/string serialization. It is a Basketball OS profile and is explicitly
**not RFC 8785 / JCS**.
`compareUnicodeCodePointStringsV1` exposes the same locale-independent string
ordering for arrays whose order enters a snapshot, ledger, or signed receipt.

## Validation

Runtime parsing preserves fail-closed Basketball OS invariants, including:

- exact Wednesday `20:00` STM schedule correction;
- safe supported source and YouTube URLs;
- unique roster, game, standing, leader, box-score, and player identities;
- coherent game state, schedule time, result, standings, and team summary;
- shooting, player sums, team totals, score, home/away, and box-score
  reconciliation;
- team statistics derived only from validated published box scores.

`validateSnapshot` is the compatibility wrapper for the existing compiler. It
throws `SnapshotValidationError`, whose `path` points at the first rejected
field.

## JSON Schema

`generatePublicContractSchemas()` uses Zod 4’s built-in `z.toJSONSchema` and
emits JSON Schema Draft 2020-12. Checked-in outputs are:

- `schemas/team-snapshot-v3.schema.json`
- `schemas/game-video-availability-v3.schema.json`

JSON Schema represents the strict structural and URL-pattern boundary. Runtime
Zod parsing remains authoritative for relationships such as score totals,
identity joins, and Wednesday scheduling.

Regenerate and verify:

```bash
npm run generate:schemas
npm run typecheck
npm test
npm run build
```

## Dependency decision

Decision reviewed 2026-07-31. Zod 4 was adopted because it is the monorepo’s
existing MIT-licensed runtime schema dependency and its maintained built-in
Draft 2020-12 emitter removes the need for a second schema-generator package.
The main trade-off is validator bundle cost. The `./types` subpath gives
render-only consumers an empty runtime module, while importers and release gates
use the strict validator.

This workspace package remains `private` until versioning, provenance, and
registry ownership are approved. Public here describes the data/trust boundary,
not an authorization to publish the package.
