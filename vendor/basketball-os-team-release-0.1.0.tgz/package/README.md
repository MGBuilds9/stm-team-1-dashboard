# `@basketball-os/team-release`

Node 22 release signing and verification for complete public
`TeamSnapshotV3` artifacts.

The package creates a strict `basketball-os.team-release.v1` bundle:

- `snapshotPayload` is standard padded base64 of the exact canonical snapshot
  UTF-8 bytes.
- `envelope` is a DSSE v1 envelope with payload type
  `application/vnd.in-toto+json`.
- the canonical in-toto Statement v1 has one `snapshot.json` subject whose
  SHA-256 digest covers those exact snapshot bytes.
- the signed predicate binds team/provider/league/season identity, audience,
  schema version, semantic content and source-set hashes, verification hash,
  code/data/compiler revisions, issue time, and release-chain continuity.
- the signature covers exact DSSE pre-authentication encoding with Ed25519.

Only Node's built-in `node:crypto` is used. Private keys are accepted as
in-memory `KeyObject` values and never serialized. Tests generate ephemeral
keys; this package contains no production keys or secrets.

## Signing

```ts
import {
  buildAndSignTeamRelease,
  computeTeamSnapshotSourceSetHash,
} from "@basketball-os/team-release";

const release = buildAndSignTeamRelease(
  {
    snapshot,
    releaseId: "stm-semi-uncs-0042",
    sequence: 42,
    previousReleaseDigest: trustedHeadDigest,
    audience: "public",
    signerKeyId: "stm-release-2026-01",
    codeRevision: "4dffe6c",
    dataRevision: "stm-summer-2026-0042",
    sourceSetHash: computeTeamSnapshotSourceSetHash(snapshot),
    verificationHash: verificationReceiptHash,
    compilerVersion: "0.1.0",
    issuedAt: new Date().toISOString(),
  },
  privateKey,
);
```

Sequence `1` must use `previousReleaseDigest: null`. Every later release must
use the `sha256:` digest returned by `computeTeamReleaseDigest` for its
predecessor.

## Verification

```ts
import {
  verifyTeamReleaseAgainstTrustedHead,
} from "@basketball-os/team-release";

const verified = verifyTeamReleaseAgainstTrustedHead(untrustedJson, {
  keys: trustedKeyRegistry,
  expectedIdentity: {
    providerId: "stm",
    leagueId: "mens-basketball",
    seasonId: "summer-2026",
    teamId: "semi-uncs",
  },
  expectedSequence: 42,
  expectedPreviousReleaseDigest: trustedHeadDigest,
});
```

Verification is fail-closed. It rejects noncanonical base64 or JSON,
unsupported DSSE/in-toto structures, an altered snapshot, semantic or source
hash drift, invalid snapshot data, future issuance, identity mismatch,
rollback/fork continuity, and unknown, invalid, revoked, not-yet-valid,
expired, or cryptographically failing keys.

Trusted key records are scoped to explicit audiences and one
provider/league/season/team identity. Rollback/fork protection must provide
both `expectedSequence` and `expectedPreviousReleaseDigest`; providing only
one fails closed.

Consumer imports should use `verifyTeamReleaseAgainstTrustedHead`. The
lower-level `verifyTeamRelease` exists for first-stage cryptographic inspection
and genesis tooling; it does not infer a local chain head when the expected
continuity fields are omitted.

The verifier performs bounded standard-base64 decoding, canonical-JSON checks,
and strict DSSE/in-toto container-shape checks before cryptographic
verification. Snapshot schema, signed predicate metadata, identity, hashes,
scope, issuance, and continuity semantics are accepted only after the Ed25519
signature verifies.

The verifier intentionally requires the signing key to remain active at
verification time. Historical key archival and transparency-log verification
are a separate trust policy and must not be inferred from this API.

## Exact-game video transition policy

`detectExactVideoTransitions(previous, next)` reports every removal or
replacement of a previously verified exact-game YouTube URL. The release
orchestrator must require a signed human-review decision for every reported
transition before calling `buildAndSignTeamRelease`. This v1 package exposes
the policy seam but does not invent or silently approve those decisions.
